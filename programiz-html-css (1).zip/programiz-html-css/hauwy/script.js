document.addEventListener("DOMContentLoaded", function() {
    alert("Selamat datang di Saran Outfit Kece! Temukan outfit favorit Anda.");
});